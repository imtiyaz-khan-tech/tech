$(document).ready(function () {
    console.log('Document Is Ready');
});